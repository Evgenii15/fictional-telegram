'''
Provides application configuration
'''

from django.apps import AppConfig

class ReactLmsConfig(AppConfig):

    name = 'react_lms'
    verbose_name = 'EdX React LMS'
