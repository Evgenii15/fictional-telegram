import React, { Component } from 'react';
import RouterRoot from 'router'
import 'sass-core/page-root-styles.scss';

class App extends Component {

  render() {

    return (
      <RouterRoot />
    );
  }
}

export default App
