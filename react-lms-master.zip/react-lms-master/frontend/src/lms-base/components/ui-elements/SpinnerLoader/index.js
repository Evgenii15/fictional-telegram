import React, { Component } from 'react';
import styles from './_SpinnerLoader.scss';

class SpinnerLoader extends Component {

  render() {
    return (
      <div className={styles['spinner-loader-wrapper']}>
        POAODoasdaodpamdpa
      </div>
    );
  }
}

export default SpinnerLoader
