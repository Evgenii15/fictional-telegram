import React, { Component } from 'react';

class TestComponent extends Component {

  render() {

    return (
      <section>
        This is a test component!
      </section>
    );
  }
}

export default TestComponent;
